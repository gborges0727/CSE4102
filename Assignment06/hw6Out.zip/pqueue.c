#include "pqueue.h"
#include <stdlib.h>

PQueue* allocPQueue()
{
    // TO-DO
    return NULL;
}

Arc* allocArc()
{
    // TO-DO
    return NULL;
}

void destroyPQueue(PQueue* pq)
{
    // TO-DO
}

void destroyArc(Arc* a)
{
    // TO-DO
}

void insert(PQueue* pq, Arc* a)
{
    // TO-DO
}

Arc* extractMin(PQueue* pq)
{
    // TO-DO
    return NULL;
}
