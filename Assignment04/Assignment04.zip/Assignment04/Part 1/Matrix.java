public class Matrix {
    private int[][] array;
    
    public Matrix(int[][] arrayToSet) {
        array = arrayToSet;
    }
    
    public int[][] getMatrix() {
        return array;
    }
}